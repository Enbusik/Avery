#include <iostream>
using namespace std;

int main()
{
  cout << "Enter an ASCII code: ";
  int code;
  cin >> code;

  char ch = code;

  cout << "The character is " << ch << endl;

  return 0;
}
